var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636052951799.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636052951799-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-e451408d-ccbc-4a45-892d-07da50b96b4f" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="PORTFOLIO info" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e451408d-ccbc-4a45-892d-07da50b96b4f-1636052951799.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/e451408d-ccbc-4a45-892d-07da50b96b4f-1636052951799-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/e451408d-ccbc-4a45-892d-07da50b96b4f-1636052951799-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="615.0px" >\
        <div id="s-Rectangle_16" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_8"   datasizewidth="300.0px" datasizeheight="257.0px" datasizewidthpx="300.0" datasizeheightpx="256.99999999999994" dataX="168.0" dataY="599.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_16_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_17" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_9"   datasizewidth="300.0px" datasizeheight="257.0px" datasizewidthpx="300.0" datasizeheightpx="257.0" dataX="168.0" dataY="599.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_17_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_35" class="pie image firer ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1217.5" dataY="20.0"   alt="image" systemName="./images/f0143bb0-a419-407d-a44d-190025c0fd43.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
          	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
          	    <title>user</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#666666" id="s-Image_35-user">\
          	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
          	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1278.0px" datasizeheight="93.1px" datasizewidthpx="1278.0" datasizeheightpx="93.0763870059319" dataX="2.5" dataY="373.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext manualfit firer ie-background commentable non-processed" customid="*ITEM* INFO"   datasizewidth="485.0px" datasizeheight="90.0px" dataX="95.5" dataY="400.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">*ITEM* INFO</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="257.5px" datasizeheight="218.0px" dataX="188.0" dataY="618.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_8" class="pie image firer click ie-background commentable non-processed" customid="Image_1"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="1141.0" dataY="405.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4f4c575b-3632-4304-8e5e-b80fa7a2aa62.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_9" class="pie image firer ie-background commentable non-processed" customid="Image_5"   datasizewidth="15.0px" datasizeheight="27.0px" dataX="1164.0" dataY="400.0"   alt="image" systemName="./images/f4ee6893-ee4e-4e76-a989-0683b945c030.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="27px" version="1.1" viewBox="0 0 15 27" width="15px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Arrow Right</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_9-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#DDDDDD" id="s-Image_9-Components" transform="translate(-463.000000, -1276.000000)">\
          	            <g id="s-Image_9-Arrow-Right" transform="translate(463.000000, 1276.000000)">\
          	                <polyline points="1.157 0 0 1.144 12.325 13.62 0 25.691 1.325 27 15 13.691 1.157 0" style="fill:#CBCBCB !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_18" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="L I N K"   datasizewidth="40.0px" datasizeheight="16.0px" dataX="1188.0" dataY="405.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_18_0">L I </span><span id="rtr-s-Paragraph_18_1">N K </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1289.0px" datasizeheight="70.0px" datasizewidthpx="1289.0" datasizeheightpx="70.0" dataX="-9.0" dataY="313.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="HOME"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="313.0" dataY="313.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">HOME</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="PORTFOLIO"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="827.0" dataY="313.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">PORTFOLIO</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="PRESUPUESTO"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="999.0" dataY="313.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">PRESUPUESTO</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="QUIENES SOMOS"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="479.0" dataY="313.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">QUIENES SOMOS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="CONTACT"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="651.0" dataY="313.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">CONTACT</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="1218.5" dataY="338.0"   alt="image" systemName="./images/6eedbf86-925f-4510-8217-b364443f97bc.svg" overlay="#DDDDDD">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_2-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
          	            <g id="s-Image_2-Search-" transform="translate(1068.000000, 17.000000)">\
          	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_2-Icon" style="fill:#DDDDDD !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="80.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1284.0px" datasizeheight="270.0px" datasizewidthpx="1284.0" datasizeheightpx="269.99999999999955" dataX="-1.0" dataY="1058.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_17" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="23.8px" datasizeheight="24.0px" dataX="1134.0" dataY="1207.0"   alt="image" systemName="./images/05a226e5-bcd2-4cd4-80cf-2636083e107c.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 24 24" width="24px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Dribbble Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_17-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#DDDDDD" id="s-Image_17-Components" transform="translate(-683.000000, -934.000000)">\
            	            <g id="s-Image_17-Social" transform="translate(100.000000, 849.000000)">\
            	                <g id="s-Image_17-Rounded-Icons" transform="translate(515.000000, 85.000000)">\
            	                    <g id="s-Image_17-Dribbble-Icon" transform="translate(68.000000, 0.000000)">\
            	                        <path d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M18,12 C18,8.688 15.312,6 12,6 C8.688,6 6,8.688 6,12 C6,15.312 8.688,18 12,18 C15.312,18 18,15.312 18,12 Z M8.856,16.044 L8.736,15.948 C8.772,15.984 8.808,16.008 8.856,16.032 L8.856,16.044 Z M12.552,11.976 C10.848,12.468 9.048,13.896 8.184,15.42 L8.196,15.432 C7.344,14.484 6.876,13.26 6.876,12 L6.876,11.832 C8.58,11.88 10.524,11.592 12.144,11.112 C12.288,11.4 12.432,11.688 12.552,11.976 Z M14.004,16.716 C13.368,16.992 12.684,17.124 12,17.124 C10.86,17.124 9.756,16.74 8.856,16.032 C8.988,15.744 9.192,15.468 9.384,15.228 C10.308,14.076 11.484,13.32 12.876,12.84 L12.9,12.828 C13.392,14.076 13.776,15.396 14.004,16.716 Z M11.712,10.32 C10.224,10.716 8.628,10.956 7.08,10.944 L6.984,10.944 C7.32,9.372 8.364,8.052 9.816,7.368 C10.512,8.304 11.148,9.3 11.712,10.32 Z M17.064,12.816 C16.836,14.208 16.032,15.456 14.868,16.248 C14.652,15.012 14.292,13.776 13.86,12.588 C14.22,12.528 14.58,12.504 14.928,12.504 C15.636,12.504 16.392,12.6 17.064,12.816 Z M15.384,8.16 C14.856,8.976 13.584,9.684 12.708,10.008 C12.144,8.976 11.508,7.956 10.788,7.02 C11.184,6.924 11.592,6.876 12,6.876 C13.248,6.876 14.448,7.332 15.384,8.16 Z M17.124,11.952 C16.344,11.784 15.528,11.712 14.736,11.712 C14.34,11.712 13.944,11.736 13.548,11.784 C13.416,11.436 13.26,11.1 13.104,10.776 C14.028,10.392 15.372,9.6 15.96,8.748 C16.704,9.648 17.112,10.776 17.124,11.952 Z" style="fill:#FFFFFF !important;" />\
            	                    </g>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_18" class="pie image firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="23.8px" datasizeheight="24.0px" dataX="1099.0" dataY="1207.0"   alt="image" systemName="./images/35524d64-f65a-44ac-b1c4-b65d24f1111a.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 24 24" width="24px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Twitter Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_18-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#DDDDDD" id="s-Image_18-Components" transform="translate(-649.000000, -934.000000)">\
            	            <g id="s-Image_18-Social" transform="translate(100.000000, 849.000000)">\
            	                <g id="s-Image_18-Rounded-Icons" transform="translate(515.000000, 85.000000)">\
            	                    <g id="s-Image_18-Twitter-Icon" transform="translate(34.000000, 0.000000)">\
            	                        <path d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M15.5433071,9.40709178 C15.5433071,9.40709178 15.5433071,9.30658522 15.5433071,9.40709178 C15.0708661,8.904559 14.503937,8.70354589 13.9370079,8.80405244 C14.503937,8.70354589 14.7874016,8.50253278 14.8818898,8.40202622 C14.8818898,8.30151967 14.8818898,8.20101311 14.7874016,8.20101311 C14.503937,8.20101311 14.2204724,8.30151967 14.0314961,8.40202622 C14.3149606,8.20101311 14.4094488,8.10050656 14.4094488,8 C14.1259843,8 13.8425197,8.20101311 13.4645669,8.50253278 C13.5590551,8.30151967 13.6535433,8.20101311 13.5590551,8.10050656 C13.3700787,8.20101311 13.2755906,8.30151967 13.1811024,8.50253278 C12.8976378,8.80405244 12.7086614,9.00506555 12.6141732,9.30658522 C12.2362205,10.0101311 11.9527559,10.6131704 11.7637795,11.3167163 L11.6692913,11.3167163 C11.480315,11.0151967 11.1968504,10.713677 10.8188976,10.5126639 C10.4409449,10.2111442 9.96850394,10.0101311 9.4015748,9.70861144 C8.83464567,9.40709178 8.26771654,9.10557211 7.60629921,8.904559 C7.60629921,9.60810489 7.88976378,10.2111442 8.5511811,10.6131704 C8.36220472,10.6131704 8.07874016,10.6131704 7.88976378,10.713677 C7.88976378,11.3167163 8.36220472,11.8192491 9.21259843,12.0202622 C8.92913386,12.0202622 8.64566929,12.1207688 8.36220472,12.3217819 C8.64566929,12.9248212 9.11811024,13.1258343 9.87401575,13.1258343 C9.77952756,13.2263409 9.59055118,13.3268474 9.59055118,13.3268474 C9.49606299,13.427354 9.4015748,13.6283671 9.49606299,13.8293802 C9.68503937,14.1308999 9.87401575,14.2314064 10.3464567,14.2314064 C9.68503937,14.9349523 8.83464567,15.3369785 7.88976378,15.236472 C7.32283465,15.236472 6.66141732,14.9349523 6,14.331913 C6.66141732,15.3369785 7.60629921,16.141031 8.74015748,16.6435638 C10.0629921,17.04559 11.3858268,17.1460965 12.6141732,16.7440703 C13.8425197,16.3420441 14.976378,15.5379917 15.8267717,14.4324196 C16.2047244,13.8293802 16.488189,13.2263409 16.5826772,12.6233016 C17.2440945,12.6233016 17.7165354,12.4222884 18,12.0202622 C17.8110236,12.1207688 17.3385827,12.1207688 16.6771654,11.9197557 C17.3385827,11.8192491 17.8110236,11.618236 17.9055118,11.2162098 C17.4330709,11.4172229 16.9606299,11.4172229 16.488189,11.2162098 C16.3937008,10.5126639 16.1102362,9.90962455 15.5433071,9.40709178 Z" style="fill:#FFFFFF !important;" />\
            	                    </g>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_19" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="23.8px" datasizeheight="24.0px" dataX="1065.0" dataY="1207.0"   alt="image" systemName="./images/b9f2b5b4-6b14-4c94-b9ed-3e2feb130049.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 24 24" width="24px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Facebook Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_19-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#DDDDDD" id="s-Image_19-Components" transform="translate(-615.000000, -934.000000)">\
            	            <g id="s-Image_19-Social" transform="translate(100.000000, 849.000000)">\
            	                <g id="s-Image_19-Rounded-Icons" transform="translate(515.000000, 85.000000)">\
            	                    <g id="s-Image_19-Facebook-Icon">\
            	                        <path d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M14.726776,8.76861702 L15,7.19946809 C14.4945355,7.02659574 13.5655738,7 13.0464481,7 C11.5300546,7 10.9016393,8.11702128 10.9016393,9.46010638 L10.9016393,10.3510638 L10,10.3510638 L10,12.1196809 L10.9016393,12.1196809 L10.9016393,17 L12.7322404,17 L12.7322404,12.1196809 L14.5491803,12.1196809 L14.5491803,10.3510638 L12.7322404,10.3510638 L12.7322404,9.30053191 C12.7322404,8.86170213 13.4972678,8.6356383 13.852459,8.6356383 C14.1393443,8.6356383 14.4535519,8.68882979 14.726776,8.76861702 Z" style="fill:#FFFFFF !important;" />\
            	                    </g>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_20" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="22.8px" datasizeheight="24.0px" dataX="1169.0" dataY="1207.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/28dded8b-a4d7-4642-9af8-811b08bac70d.png" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Paragraph_19" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Lorem ipsum dolor sit ame"   datasizewidth="271.0px" datasizeheight="31.0px" dataX="504.5" dataY="1162.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_19_0">Lorem ipsum dolor sit amet</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_20" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Contacto: XXXXXXXXX"   datasizewidth="271.0px" datasizeheight="31.0px" dataX="112.0" dataY="1099.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_20_0">Contacto: XXXXXXXXX</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_21" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Email: loremipsum@dolorsi"   datasizewidth="271.0px" datasizeheight="31.0px" dataX="901.0" dataY="1099.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_21_0">Email: loremipsum@dolorsit.amet</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_13" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_7"   datasizewidth="1279.0px" datasizeheight="53.0px" datasizewidthpx="1279.0" datasizeheightpx="53.0" dataX="3.0" dataY="1275.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_13_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_22" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Dynamic software S.L."   datasizewidth="171.0px" datasizeheight="31.0px" dataX="556.0" dataY="1286.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_22_0">Dynamic software S.L.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_21" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="184.6px" datasizeheight="172.0px" dataX="550.2" dataY="1021.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/5d8244f0-a8a9-440b-8018-70a46c38b203.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Lorem ipsum dolor sit ame"   datasizewidth="400.0px" datasizeheight="169.0px" dataX="690.0" dataY="631.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Lorem ipsum dolor sit amet, sapien etiam, nunc amet dolor ac odio mauris justo. Luctus arcu, urna praesent at id quisque ac. Arcu es massa vestibulum malesuada, integer vivamus elit eu mauris eus, cum eros quis aliquam wisi. Nulla wisi laoreet suspendisse integer vivamus elit eu mauris hendrerit facilisi, mi mattis pariatur aliquam pharetra eget.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="71.0px" datasizeheight="11.0px" dataX="282.5" dataY="895.0"   alt="image" systemName="./images/cb3ab9f8-c8e6-4e03-9477-91fabb1e9548.svg" overlay="">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' width="71px" height="11px" viewBox="0 0 71 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Rating</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs></defs>\
          	    <g id="s-Image_3-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
          	        <g id="Testimonials-#6" transform="translate(-657.000000, -51.000000)">\
          	            <g id="s-Image_3-Rating" transform="translate(657.000000, 51.000000)">\
          	                <path d="M71,4.235 C71,4.015 70.5986159,3.9875 70.432526,3.9875 L66.5570934,4.00125 L65.3529412,0.44 C65.2975779,0.28875 65.1868512,0 64.9930796,0 C64.799308,0 64.6885813,0.28875 64.633218,0.44 L63.4429066,4.00125 L59.5536332,3.9875 C59.3875433,3.9875 59,4.015 59,4.235 C59,4.4 59.2076125,4.565 59.3321799,4.6475 L62.4740484,6.8475 L61.2698962,10.40875 C61.2283737,10.51875 61.200692,10.62875 61.200692,10.73875 C61.200692,10.87625 61.2698962,11 61.4083045,11 C61.5743945,11 61.7266436,10.90375 61.8512111,10.8075 L64.9930796,8.62125 L68.1349481,10.8075 C68.2595156,10.89 68.4117647,11 68.5778547,11 C68.7301038,11 68.7716263,10.8625 68.7716263,10.725 C68.7716263,10.615 68.7577855,10.505 68.716263,10.40875 L67.5259516,6.8475 L70.6678201,4.6475 C70.7923875,4.565 71,4.4 71,4.235 L71,4.235 Z" id="s-Image_3-t-4" fill="#B2B2B2"></path>\
          	                <path d="M56,4.235 C56,4.015 55.5986159,3.9875 55.432526,3.9875 L51.5570934,4.00125 L50.3529412,0.44 C50.2975779,0.28875 50.1868512,0 49.9930796,0 C49.799308,0 49.6885813,0.28875 49.633218,0.44 L48.4429066,4.00125 L44.5536332,3.9875 C44.3875433,3.9875 44,4.015 44,4.235 C44,4.4 44.2076125,4.565 44.3321799,4.6475 L47.4740484,6.8475 L46.2698962,10.40875 C46.2283737,10.51875 46.200692,10.62875 46.200692,10.73875 C46.200692,10.87625 46.2698962,11 46.4083045,11 C46.5743945,11 46.7266436,10.90375 46.8512111,10.8075 L49.9930796,8.62125 L53.1349481,10.8075 C53.2595156,10.89 53.4117647,11 53.5778547,11 C53.7301038,11 53.7716263,10.8625 53.7716263,10.725 C53.7716263,10.615 53.7577855,10.505 53.716263,10.40875 L52.5259516,6.8475 L55.6678201,4.6475 C55.7923875,4.565 56,4.4 56,4.235 L56,4.235 Z" id="s-Image_3-Star" fill="#B2B2B2"></path>\
          	                <path d="M40.432526,3.9875 L36.5570934,4.00125 L35.3529412,0.44 C35.2975779,0.28875 35.1868512,0 34.9930796,0 C34.799308,0 34.6885813,0.28875 34.633218,0.44 L33.4429066,4.00125 L29.5536332,3.9875 C29.3875433,3.9875 29,4.015 29,4.235 C29,4.4 29.2076125,4.565 29.3321799,4.6475 L32.4740484,6.8475 L31.2698962,10.40875 C31.2283737,10.51875 31.200692,10.62875 31.200692,10.73875 C31.200692,10.87625 31.2698962,11 31.4083045,11 C31.5743945,11 31.7266436,10.90375 31.8512111,10.8075 L34.9930796,8.62125 L38.1349481,10.8075 C38.2595156,10.89 38.4117647,11 38.5778547,11 C38.7301038,11 38.7716263,10.8625 38.7716263,10.725 C38.7716263,10.615 38.7577855,10.505 38.716263,10.40875 L37.5259516,6.8475 L40.6678201,4.6475 C40.7923875,4.565 41,4.4 41,4.235 C41,4.015 40.5986159,3.9875 40.432526,3.9875 Z" id="s-Image_3-Star-Active" fill="#282828"></path>\
          	                <path d="M25.432526,3.9875 L21.5570934,4.00125 L20.3529412,0.44 C20.2975779,0.28875 20.1868512,0 19.9930796,0 C19.799308,0 19.6885813,0.28875 19.633218,0.44 L18.4429066,4.00125 L14.5536332,3.9875 C14.3875433,3.9875 14,4.015 14,4.235 C14,4.4 14.2076125,4.565 14.3321799,4.6475 L17.4740484,6.8475 L16.2698962,10.40875 C16.2283737,10.51875 16.200692,10.62875 16.200692,10.73875 C16.200692,10.87625 16.2698962,11 16.4083045,11 C16.5743945,11 16.7266436,10.90375 16.8512111,10.8075 L19.9930796,8.62125 L23.1349481,10.8075 C23.2595156,10.89 23.4117647,11 23.5778547,11 C23.7301038,11 23.7716263,10.8625 23.7716263,10.725 C23.7716263,10.615 23.7577855,10.505 23.716263,10.40875 L22.5259516,6.8475 L25.6678201,4.6475 C25.7923875,4.565 26,4.4 26,4.235 C26,4.015 25.5986159,3.9875 25.432526,3.9875 Z" id="s-Image_3-Star-Active" fill="#282828"></path>\
          	                <path d="M12,4.235 C12,4.015 11.5986159,3.9875 11.432526,3.9875 L7.55709343,4.00125 L6.35294118,0.44 C6.29757785,0.28875 6.18685121,0 5.99307958,0 C5.79930796,0 5.68858131,0.28875 5.63321799,0.44 L4.44290657,4.00125 L0.553633218,3.9875 C0.387543253,3.9875 0,4.015 0,4.235 C0,4.4 0.207612457,4.565 0.332179931,4.6475 L3.47404844,6.8475 L2.26989619,10.40875 C2.2283737,10.51875 2.20069204,10.62875 2.20069204,10.73875 C2.20069204,10.87625 2.26989619,11 2.4083045,11 C2.57439446,11 2.7266436,10.90375 2.85121107,10.8075 L5.99307958,8.62125 L9.1349481,10.8075 C9.25951557,10.89 9.41176471,11 9.57785467,11 C9.73010381,11 9.7716263,10.8625 9.7716263,10.725 C9.7716263,10.615 9.75778547,10.505 9.71626298,10.40875 L8.52595156,6.8475 L11.6678201,4.6475 C11.7923875,4.565 12,4.4 12,4.235 L12,4.235 Z" id="s-Image_3-Star-Active" fill="#282828"></path>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_25" class="pie image firer click ie-background commentable non-processed" customid="Image_24"   datasizewidth="238.0px" datasizeheight="239.0px" dataX="521.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/520cbaef-9203-43a8-ad8e-3a03bad5ea6e.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_6" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="PORTFOLIO INFO"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="882.0" dataY="330.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">PORTFOLIO INFO</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;