	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image_35", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_2", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Contact 3", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Input_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Contact 3", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_2", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Contact 3", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Paragraph 1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Mail icon", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Phone icon", "s-Image_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Paragraph 1", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Paragraph 1", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Image_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["RSS", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_5", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Twitter", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Facebook", "s-Image_6"]; 

	widgets.descriptionMap[["s-Input_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Contact 3", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Contact 3", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_7", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Title", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Title", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Title", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Rectangle_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image_25", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Location pin", "s-Image_25"]; 

	widgets.descriptionMap[["s-Rectangle_5", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["h2", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_2", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Menu burger", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_7", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["False", "s-Image_7"]; 

	widgets.descriptionMap[["s-Image_8", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Right arrow", "s-Image_8"]; 

	widgets.descriptionMap[["s-Paragraph_14", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Image_9", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Menu burger", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_11", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["World icon", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_12", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Twitter circle", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_13", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["FB circle", "s-Image_13"]; 

	widgets.descriptionMap[["s-Image_14", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["World icon", "s-Image_14"]; 

	widgets.descriptionMap[["s-Image_15", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_15", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["False", "s-Image_15"]; 

	widgets.descriptionMap[["s-Rectangle_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Small dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_16", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["World icon", "s-Image_16"]; 

	widgets.descriptionMap[["s-Image_17", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Twitter circle", "s-Image_17"]; 

	widgets.descriptionMap[["s-Image_18", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["FB circle", "s-Image_18"]; 

	widgets.descriptionMap[["s-Image_19", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["World icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Paragraph_16", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["h4", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["h4", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Paragraph_18", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["h4", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Rectangle_8", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Paragraph_19", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["h4", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Image_20", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_20", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["False", "s-Image_20"]; 

	widgets.descriptionMap[["s-Image_26", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_26", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Picture", "s-Image_26"]; 

	widgets.descriptionMap[["s-Paragraph_10", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "7c0fe5fb-3511-4422-8920-8cd5fac431b6"]] = ["Title", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Rectangle_11", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_16", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_17", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_35", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_6", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Paragraph_6", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["h2", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_1", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Image placeholder", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_3", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Image placeholder", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_8", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["False", "s-Image_8"]; 

	widgets.descriptionMap[["s-Image_9", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Right arrow", "s-Image_9"]; 

	widgets.descriptionMap[["s-Paragraph_18", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Link", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Image_2", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Menu burger", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_12", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["World icon", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_13", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Twitter circle", "s-Image_13"]; 

	widgets.descriptionMap[["s-Image_14", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["FB circle", "s-Image_14"]; 

	widgets.descriptionMap[["s-Image_15", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_15", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["World icon", "s-Image_15"]; 

	widgets.descriptionMap[["s-Image_16", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["False", "s-Image_16"]; 

	widgets.descriptionMap[["s-Rectangle_1", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Small dark footer 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Image_17", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["World icon", "s-Image_17"]; 

	widgets.descriptionMap[["s-Image_18", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Twitter circle", "s-Image_18"]; 

	widgets.descriptionMap[["s-Image_19", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["FB circle", "s-Image_19"]; 

	widgets.descriptionMap[["s-Image_20", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_20", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["World icon", "s-Image_20"]; 

	widgets.descriptionMap[["s-Paragraph_19", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["h4", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Paragraph_20", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["h4", "s-Paragraph_20"]; 

	widgets.descriptionMap[["s-Paragraph_21", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["h4", "s-Paragraph_21"]; 

	widgets.descriptionMap[["s-Rectangle_13", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Rectangle", "s-Rectangle_13"]; 

	widgets.descriptionMap[["s-Paragraph_22", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_22", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["h4", "s-Paragraph_22"]; 

	widgets.descriptionMap[["s-Image_21", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_21", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["False", "s-Image_21"]; 

	widgets.descriptionMap[["s-Image_25", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Picture", "s-Image_25"]; 

	widgets.descriptionMap[["s-Rectangle_12", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_19", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_3"]; 

	widgets.descriptionMap[["s-Image_4", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Image placeholder", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_5", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Image placeholder", "s-Image_5"]; 

	widgets.descriptionMap[["s-Rectangle_14", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_20", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_21", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Blog 4", "s-Group_5"]; 

	widgets.descriptionMap[["s-Image_6", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Image placeholder", "s-Image_6"]; 

	widgets.descriptionMap[["s-Image_7", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "9e907936-99d3-47a3-aace-e4b8f5d58fd8"]] = ["Image placeholder", "s-Image_7"]; 

	widgets.descriptionMap[["s-Image_35", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h2", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["False", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Right arrow", "s-Image_5"]; 

	widgets.descriptionMap[["s-Paragraph_14", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Image_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Menu burger", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["World icon", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Twitter circle", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_11", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["FB circle", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_12", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["World icon", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_13", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["False", "s-Image_13"]; 

	widgets.descriptionMap[["s-Rectangle_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Small dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_14", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["World icon", "s-Image_14"]; 

	widgets.descriptionMap[["s-Image_15", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_15", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Twitter circle", "s-Image_15"]; 

	widgets.descriptionMap[["s-Image_16", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["FB circle", "s-Image_16"]; 

	widgets.descriptionMap[["s-Image_17", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["World icon", "s-Image_17"]; 

	widgets.descriptionMap[["s-Paragraph_16", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Paragraph_18", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Rectangle_8", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Paragraph_19", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Image_21", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_21", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["False", "s-Image_21"]; 

	widgets.descriptionMap[["s-Image_25", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Picture", "s-Image_25"]; 

	widgets.descriptionMap[["s-Line_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Line_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Line", "s-Line_6"]; 

	widgets.descriptionMap[["s-Circle_8", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_8", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Circle_8"]; 

	widgets.descriptionMap[["s-Circle_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Circle_9"]; 

	widgets.descriptionMap[["s-Circle_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Circle_10"]; 

	widgets.descriptionMap[["s-Image_20", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_20", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Close icon", "s-Image_20"]; 

	widgets.descriptionMap[["s-Image_19", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Check mark", "s-Image_19"]; 

	widgets.descriptionMap[["s-Image_23", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Close icon", "s-Image_23"]; 

	widgets.descriptionMap[["s-Category_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Native dropdown", "s-Category_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Category", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Category", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Radio List", "s-Category"]; 

	widgets.descriptionMap[["s-Paragraph_7", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Rectangle_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dark button", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Panel_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Path_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Line", "s-Path_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Ellipse_1"]; 

	widgets.descriptionMap[["s-Ellipse_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Ellipse_2"]; 

	widgets.descriptionMap[["s-Ellipse_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Ellipse_3"]; 

	widgets.descriptionMap[["s-Image_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Check mark", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Close icon", "s-Image_6"]; 

	widgets.descriptionMap[["s-Category_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Category_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Radio List", "s-Category_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["h4", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Image_7", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Check mark", "s-Image_7"]; 

	widgets.descriptionMap[["s-Rectangle_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dark button", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dark button", "s-Rectangle_9"]; 

	widgets.descriptionMap[["s-Panel_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Path_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Line", "s-Path_2"]; 

	widgets.descriptionMap[["s-Ellipse_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Ellipse_4"]; 

	widgets.descriptionMap[["s-Ellipse_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Ellipse_5"]; 

	widgets.descriptionMap[["s-Ellipse_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Circle", "s-Ellipse_6"]; 

	widgets.descriptionMap[["s-Image_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Check mark", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_18", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Check mark", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dark button", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dark button", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Image_24", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Image_24", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Check mark", "s-Image_24"]; 

	widgets.descriptionMap[["s-Rectangle_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Rectangle", "s-Rectangle_10"]; 

	widgets.descriptionMap[["s-Input_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Paragraph_11", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Title", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Input_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Input_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Paragraph_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Title", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Title", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Input_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Paragraph_8", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Title", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Input_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Paragraph_12", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Title", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Panel_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"]] = ["Dynamic Panel", "s-Dynamic_Panel"]; 

	widgets.descriptionMap[["s-Rectangle_16", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Blog 4", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_17", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Blog 4", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_35", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_6", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Paragraph_6", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["h2", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_1", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Image placeholder", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_8", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["False", "s-Image_8"]; 

	widgets.descriptionMap[["s-Image_9", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Right arrow", "s-Image_9"]; 

	widgets.descriptionMap[["s-Paragraph_18", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Link", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Image_2", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Menu burger", "s-Image_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Small dark footer 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Image_17", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["World icon", "s-Image_17"]; 

	widgets.descriptionMap[["s-Image_18", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Twitter circle", "s-Image_18"]; 

	widgets.descriptionMap[["s-Image_19", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["FB circle", "s-Image_19"]; 

	widgets.descriptionMap[["s-Image_20", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_20", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["World icon", "s-Image_20"]; 

	widgets.descriptionMap[["s-Paragraph_19", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["h4", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Paragraph_20", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["h4", "s-Paragraph_20"]; 

	widgets.descriptionMap[["s-Paragraph_21", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["h4", "s-Paragraph_21"]; 

	widgets.descriptionMap[["s-Rectangle_13", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Rectangle", "s-Rectangle_13"]; 

	widgets.descriptionMap[["s-Paragraph_22", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_22", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["h4", "s-Paragraph_22"]; 

	widgets.descriptionMap[["s-Image_21", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_21", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["False", "s-Image_21"]; 

	widgets.descriptionMap[["s-Paragraph_1", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_3", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Rating", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_25", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "e451408d-ccbc-4a45-892d-07da50b96b4f"]] = ["Picture", "s-Image_25"]; 

	widgets.descriptionMap[["s-Image_35", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_5", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["h2", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_1", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["False", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_5", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Right arrow", "s-Image_5"]; 

	widgets.descriptionMap[["s-Paragraph_14", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Image_2", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Menu burger", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_3", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Image placeholder", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_9", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["World icon", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_10", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Twitter circle", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_11", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["FB circle", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_12", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["World icon", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_13", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["False", "s-Image_13"]; 

	widgets.descriptionMap[["s-Rectangle_1", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Small dark footer 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_14", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["World icon", "s-Image_14"]; 

	widgets.descriptionMap[["s-Image_15", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_15", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Twitter circle", "s-Image_15"]; 

	widgets.descriptionMap[["s-Image_16", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["FB circle", "s-Image_16"]; 

	widgets.descriptionMap[["s-Image_17", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["World icon", "s-Image_17"]; 

	widgets.descriptionMap[["s-Paragraph_16", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["h4", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["h4", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Paragraph_18", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["h4", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Rectangle_8", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Paragraph_19", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["h4", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Image_18", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["False", "s-Image_18"]; 

	widgets.descriptionMap[["s-Image_25", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "aa7e2539-41a3-418f-81bc-18740d06171f"]] = ["Picture", "s-Image_25"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h2", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu burger", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["False", "s-Image_7"]; 

	widgets.descriptionMap[["s-Image_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Right arrow", "s-Image_8"]; 

	widgets.descriptionMap[["s-Paragraph_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Link", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image placeholder", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image placeholder", "s-Image_3"]; 

	widgets.descriptionMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h3", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h3", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image placeholder", "s-Image_4"]; 

	widgets.descriptionMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h3", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image placeholder", "s-Image_5"]; 

	widgets.descriptionMap[["s-Paragraph_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h3", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Small dark footer 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["World icon", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Twitter circle", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["FB circle", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["World icon", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["False", "s-Image_13"]; 

	widgets.descriptionMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 4", "s-Slider_4"]; 

	widgets.descriptionMap[["s-Arrow_right", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Arrow_right", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Chev Right", "s-Arrow_right"]; 

	widgets.descriptionMap[["s-Arrow_left", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Arrow_left", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Chev Left", "s-Arrow_left"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 4", "s-Slider_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 4", "s-Slider_4"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 4", "s-Slider_4"]; 

	widgets.descriptionMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 4", "s-Slider_4"]; 

	widgets.descriptionMap[["s-Paragraph_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 4", "s-Slider_4"]; 

	widgets.descriptionMap[["s-Paragraph_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h4", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h4", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Paragraph_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h4", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Rectangle_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Paragraph_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h4", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Image_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Picture", "s-Image_25"]; 

	