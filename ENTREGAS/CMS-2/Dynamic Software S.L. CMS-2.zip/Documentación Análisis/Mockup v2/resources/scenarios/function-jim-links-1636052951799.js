(function(window, undefined) {

  var jimLinks = {
    "7c0fe5fb-3511-4422-8920-8cd5fac431b6" : {
      "Image_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_14" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_3" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_4" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_5" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Image_26" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_6" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ]
    },
    "9e907936-99d3-47a3-aace-e4b8f5d58fd8" : {
      "Image_8" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_18" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_3" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_4" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_5" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Image_25" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_6" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ]
    },
    "bf1a1caa-7fd2-4279-a19e-5efbd64d6840" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_14" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_3" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_4" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_5" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Image_25" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_6" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ]
    },
    "e451408d-ccbc-4a45-892d-07da50b96b4f" : {
      "Image_8" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_18" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_3" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_4" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_5" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Image_25" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_6" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ]
    },
    "aa7e2539-41a3-418f-81bc-18740d06171f" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_14" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_3" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_4" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_5" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Image_25" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_6" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "9e907936-99d3-47a3-aace-e4b8f5d58fd8"
      ],
      "Text_3" : [
        "bf1a1caa-7fd2-4279-a19e-5efbd64d6840"
      ],
      "Text_4" : [
        "aa7e2539-41a3-418f-81bc-18740d06171f"
      ],
      "Text_5" : [
        "7c0fe5fb-3511-4422-8920-8cd5fac431b6"
      ],
      "Image_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_15" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_25" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_6" : [
        "e451408d-ccbc-4a45-892d-07da50b96b4f"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);